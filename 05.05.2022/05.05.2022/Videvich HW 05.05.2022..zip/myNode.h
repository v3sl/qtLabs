#pragma once

struct node {
	int data;
	node* left;
	node* right;
};