#include "mywidget.h"

MyWidget::MyWidget(QWidget* parent) : QWidget{ parent } {
	startPoint = QPoint(100, 100);
	points.push_back(startPoint);
	endPoint = QPoint(100, 100);
	paintStep = 50;
	penWidth = 3;
	color = Qt::green;
}
void MyWidget::paintEvent(QPaintEvent*) {
	QPainter painter(this);
	int imageWidth = width();
	int imageHeight = height();
	painter.drawPixmap(0, 0, imageWidth, imageHeight, backgroundImage);
	painter.setPen(currentPen);
	for (int i = 1; i < points.size(); ++i) {
		if (points.size() == 0)
			break;
		if ((points[i - 1].x() == -1 && points[i - 1].y() == -1) || 
			(points[i].rx() == -1 && points[i].ry() == -1))
			continue;
		else
			painter.drawLine(points[i - 1], points[i]);
	}
}
void MyWidget::keyPressEvent(QKeyEvent* event) {
	switch (event->key()) {
	case Qt::Key_Right:
		endPoint = QPoint(endPoint.rx() + paintStep, endPoint.ry());
		points.push_back(endPoint);
		update();
		break;
	case Qt::Key_Left:
		endPoint = QPoint(endPoint.rx() - paintStep, endPoint.ry());
		points.push_back(endPoint);
		update();
		break;
	case Qt::Key_Up:
		endPoint = QPoint(endPoint.rx(), endPoint.ry() - paintStep);
		points.push_back(endPoint);
		update();
		break;
	case Qt::Key_Down:
		endPoint = QPoint(endPoint.rx(), endPoint.ry() + paintStep);
		points.push_back(endPoint);
		update();
		break;
	case Qt::Key_S: {
		bool ok;
		QString newStep = QInputDialog::getText(this, tr("QInputDialog::getText()"),
			tr(""), QLineEdit::Normal,
			"", &ok);
		if (ok && !newStep.isEmpty())
			paintStep = newStep.toInt();
		break;
	}
	case Qt::Key_W: {
		bool ok;
		QString newWidth = QInputDialog::getText(this, tr("QInputDialog::getText()"),
			tr(""), QLineEdit::Normal,
			"", &ok);
		if (ok && !newWidth.isEmpty())
			currentPen.setWidth(newWidth.toInt());
		break;
		update();
	}
	case Qt::Key_C: {
		QColor newColor = QColorDialog::getColor();
		currentPen.setColor(newColor);
	}
	case Qt::Key_N:
		points.clear();
		startPoint = QPoint(100, 100);
		points.push_back(startPoint);
		endPoint = QPoint(100, 100);
		paintStep = 50;
		penWidth = 3;
		color = Qt::green;
		update();
		break;
	case Qt::Key_O: {
		QString fileName = QFileDialog::getOpenFileName(this, tr("Open file"), "", tr("Images (*.png *.xpm *.jpg)"));
		QImage imageFromFile;
		imageFromFile.load(fileName);
		backgroundImage = QPixmap::fromImage(imageFromFile);
		int imageWidth = width();
		int imageHeight = height();
		backgroundImage = backgroundImage.scaled(imageWidth, imageHeight);
		break;
	}
	case Qt::Key_A: {
		QString fileName = QFileDialog::getSaveFileName(this, tr("Save as"), "untitled.png", tr("Images(*.png * .xpm * .jpg"));
		int nameEndPosition = fileName.lastIndexOf('.');
		++nameEndPosition;
		int nameLength = fileName.length() - nameEndPosition;
		QString format = fileName.right(nameLength);
		int imageWidth = width();
		int imageHeight = height();
		QPixmap imageForSave = QPixmap::grabWidget(this, 0, 0, imageWidth, imageHeight);
		imageForSave.save(fileName, format.toUpper().toUtf8());
		break;
	}
	case Qt::Key_K: {
		bool ok;
		QString newCoordinates = QInputDialog::getText(this, tr("QInputDialog::getText()"),
			tr(""), QLineEdit::Normal,
			"", &ok);
		if (ok && !newCoordinates.isEmpty()) {
			QString newX;
			QString newY;
			for (int i = 0; newCoordinates[i] != ' '; ++i)
				newX.push_back(newCoordinates[i]);
			for (int i = newX.size(); newCoordinates[i] != '\0'; ++i)
				newY.push_back(newCoordinates[i]);
			QPoint newStartPoint(newX.toInt(), newY.toInt());
			startPoint = newStartPoint;
			points.push_back(QPoint(-1, -1));
			points.push_back(startPoint);
			endPoint = startPoint;

		}
		break;
		update();
	}
	}
}