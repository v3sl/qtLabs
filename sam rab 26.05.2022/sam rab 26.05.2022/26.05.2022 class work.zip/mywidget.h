#ifndef MYWIDGET_H
#define MYWIDGET_H

#include <QWidget>
#include <QPoint>
#include <QInputDialog>
#include <QPen>
#include <QColor>
#include <QColorDialog>
#include <QFileDialog>
#include <QVBoxLayout>
#include <QPainter>
#include <QKeyEvent>

class MyWidget : public QWidget {
	Q_OBJECT
public:
	explicit MyWidget(QWidget* parent = nullptr);
signals:
protected:
	void paintEvent(QPaintEvent*) override;
	void keyPressEvent(QKeyEvent*) override;
private:
	QPen currentPen;
	QInputDialog* changePaintStep;
	int paintStep;
	int penWidth;
	QColor color;
	QVector<QPoint> points;
	QPoint startPoint;
	QPoint endPoint;
	QPixmap backgroundImage;
};
#endif 